/* script.js — small helpers for nav and footer year
   Patched: use closest('a') for anchor clicks, keep aria-expanded, clear inline nav style on wide screens.
*/

(function(){
  // Mobile menu toggle
  var btn = document.getElementById('menu-toggle');
  var nav = document.getElementById('site-nav');

  if (btn) {
    // accessibility attributes
    btn.setAttribute('aria-controls', 'site-nav');
    btn.setAttribute('aria-expanded', 'false');
    btn.setAttribute('type', 'button');

    btn.addEventListener('click', function(){
      var isOpen = nav && (nav.style.display === 'block');
      if(isOpen){
        nav.style.display = '';
        btn.setAttribute('aria-label', 'Open navigation');
        btn.setAttribute('aria-expanded', 'false');
      } else {
        if(nav) nav.style.display = 'block';
        btn.setAttribute('aria-label', 'Close navigation');
        btn.setAttribute('aria-expanded', 'true');
      }
    });
  }

  // Close nav when a link is clicked (mobile)
  if(nav){
    nav.addEventListener('click', function(e){
      var a = e.target.closest && e.target.closest('a');
      if(a && window.innerWidth < 880){
        nav.style.display = '';
        if(btn) {
          btn.setAttribute('aria-label', 'Open navigation');
          btn.setAttribute('aria-expanded', 'false');
        }
      }
    });
  }

  // Ensure inline styles don't break desktop layout on resize
  function handleResize(){
    if(window.innerWidth >= 880 && nav && nav.style.display){
      nav.style.display = '';
      if(btn) {
        btn.setAttribute('aria-expanded', 'false');
        btn.setAttribute('aria-label', 'Open navigation');
      }
    }
  }
  window.addEventListener('resize', handleResize);

  // Fill current year in footer
  var y = new Date().getFullYear();
  var el = document.getElementById('current-year');
  if(el) el.textContent = y;

  // Smooth scrolling for anchor links (use closest to handle inner clicks)
  document.addEventListener('click', function(e){
    var a = e.target.closest && e.target.closest('a');
    if(!a) return;
    var href = a.getAttribute('href');
    if(!href || !href.startsWith('#')) return;
    var id = href.slice(1);
    if(!id) return; // skip bare "#"
    var target = document.getElementById(id);
    if(target){
      e.preventDefault();
      target.scrollIntoView({behavior: 'smooth', block: 'start'});
    }
  });

})();
