# INTEGIRLS Bangalore — Website

Live site (after you enable Pages):  
https://reputation-1989.github.io/integirls-bangalore/

This repo contains a simple static site:
- `index.html` — main page
- `style.css` — styles
- `script.js` — small JS helpers (menu + smooth scroll)
- `logo.png`, `avatar-placeholder.png` (optional image placeholders)

How to publish (browser-only):
1. Create a new repo on GitHub named `integirls-bangalore`.
2. Upload these files to the repo root and commit.
3. In the repository, go to **Settings → Pages**, choose **Branch: main** and **Folder: / (root)**, then **Save**.
4. After ~1 minute open: `https://reputation-1989.github.io/integirls-bangalore/`

Notes:
- If you name the repo `integirls-bangalore.github.io` the site will be at `https://reputation-1989.github.io/`.
- Add `.nojekyll` (included) to avoid Jekyll processing issues.
